#include <iostream>

using namespace std;

// Define a structure for a node in the binary tree
struct Node
{
    int val;        // Value of the node
    Node* left;     // Pointer to the left child node
    Node* right;    // Pointer to the right child node

    // Constructor to initialize a node with a given value
    Node(int x)
    {
        val = x;    // Initialize the value
        left = nullptr; // Initialize left child pointer to null
        right = nullptr; // Initialize right child pointer to null
    }
};

// Define a class for the binary tree
class Tree
{
public:
    // Function to find the lowest common ancestor of two nodes in the binary search tree
    Node* common(Node* root, Node* p, Node* q)
    {
        // If the root is null, return null (base case)
        if (!root)
        {
            return nullptr;
        }

        // If both nodes are greater than the root, search in the right subtree
        if (p->val > root->val && q->val > root->val)
        {
            return common(root->right, p, q);
        }
        // If both nodes are smaller than the root, search in the left subtree
        else if (p->val < root->val && q->val < root->val)
        {
            return common(root->left, p, q);
        }
        // If one node is greater and the other is smaller than the root, return the root
        else
        {
            return root;
        }
    }
};

int main()
{
    // Create an object of the Tree class
    Tree obj;

    // Create a binary search tree
    Node* root = new Node(6);
    root->left = new Node(2);
    root->right = new Node(8);
    root->left->left = new Node(0);
    root->left->right = new Node(4);
    root->right->left = new Node(7);
    root->right->right = new Node(9);
    root->left->right->left = new Node(3);
    root->left->right->right = new Node(5);

    // Define two nodes p and q
    Node* p = root->left; // Node p is the left child of the root
    Node* q = root->right; // Node q is the right child of the root

    // Find the lowest common ancestor of nodes p and q
    Node* temp = obj.common(root, p, q);

    // Print the value of the lowest common ancestor
    cout << "Lowest Common Ancestor: " << temp->val << endl;

    // Delete dynamically allocated memory to avoid memory leaks
    delete root;

    // Pause the system to see the output (for Windows systems)
    system("pause");

    // Return 0 to indicate successful completion of the program
    return 0;
}
